# AviatorRobot 双臂操纵盘控制

`aviator::Aviator` 管理左右两个 `rocos::Robot`，共用一个 `rocos::Hardware`。
底层代码直接编译自 `reference/RCMRobot`，上层负责双臂同步、抓取和操纵盘运动。
控制程序与 MuJoCo 是独立进程，控制器仅下发双臂 14 轴目标。操纵盘两轴始终
没有 actuator，通过双臂与把手之间的两组 weld 约束被动运动。

## 编译和运行

在 AVIATOR 仓库根目录执行。需要 C++17、CMake、Boost、Eigen3、yaml-cpp、
orocos-kdl、urdfdom、TinyXML/TinyXML2、OpenSSL；其他控制依赖随 RCMRobot 提供。
可视化另需 GLFW/OpenGL。

```bash
# 编译仿真器
cmake -S reference/rocos-mujoco -B reference/rocos-mujoco/build/aviator-visual \
  -DCMAKE_BUILD_TYPE=Release -DROCOS_MUJOCO_ENABLE_VISUALIZATION=ON
cmake --build reference/rocos-mujoco/build/aviator-visual -j4

# 编译控制器
cmake -S AviatorRobot -B AviatorRobot/build -DCMAKE_BUILD_TYPE=Release
cmake --build AviatorRobot/build -j4
```

终端 1 启动仿真：

```bash
./reference/rocos-mujoco/build/aviator-visual/bin/rocos_mujoco_sim -v
```

终端 2 启动自动演示，约半分钟完成接近、锁定、三次转动/推拉、解锁和去使能：

```bash
./AviatorRobot/build/bin/aviatorAppMain --demo
```

不加 `--demo` 进入交互模式，依次输入以下命令。运动命令异步执行，收到完成状态后
再下发下一条；运动期间可以输入 `status` 或 `stop`。

```text
enable
approach
lock
wheel 0.12 -0.04 4
wheel -0.12 -0.07 4
wheel 0 -0.02 4
unlock
disable
quit
```

`wheel` 的参数为绝对转角（rad）、绝对推拉位移（m）、运动时间（s，可省略，默认 4）。
零位和正方向沿用 `urdf/aviator.urdf`：转角范围 `[-0.87266, 0.87266]`，
位移范围 `[-0.165, 0]`。合法数值还必须通过双臂的共同可达性、关节位置/速度和
碰撞检查，并不保证整个矩形范围都可执行。演示验证的目标为
`(0.12, -0.04)`、`(-0.12, -0.07)`、`(0, -0.02)`。

两个进程可通过同一个 `--ecat-id N` 使用另一组共享内存。
`--config /path/to/aviator.yaml` 可覆盖控制配置。支持从其他工作目录启动。

## C++ 接口

头文件为 `include/aviator/Aviator.hpp`，链接 CMake 目标 `aviator`：

```cpp
aviator::Aviator robot("AviatorRobot/config/aviator.yaml", 0);
robot.Init();
robot.Enable();
robot.ApproachHandles();
robot.LockHandles();
robot.MoveWheel(0.12, -0.04, 4.0);
auto feedback = robot.GetStatus();
robot.UnlockHandles();
robot.Disable();
```

公共动作接口为阻塞调用，错误通过 `std::runtime_error` 返回。每个实例同一时刻执行一个动作。
`Stop()` 可从另一线程调用，中止规划或执行，并让两臂保持当前位置；已经建立的抓取
约束保留。`UnlockHandles()` 显式释放约束。异常后可以先 `unlock`、`reset`，再重新接近。
`GetStatus()` 返回操纵盘实测位置/速度、左右位姿误差、ready/locked/fault 和命令确认。
`GetState()` 返回控制器动作状态；它与仿真端的锁定状态分别报告。

## 配置与模型

- `config/aviator_control.urdf` 从原始 `urdf/aviator.urdf` 生成，补充 ROCOS 使用的
  `<hardware>` 节点。左臂 1–7 轴对应从站 0–6，右臂对应 7–13，操纵盘无驱动映射。
- `config/grasp.json` 是模型与控制器共用的抓取定义。位置和四元数（wxyz）均相对于
  `steering_wheel` 坐标系；默认 TCP 为法兰沿自身 Z 轴延伸 0.10 m 的虚拟工具。
  仿真中用灰色细杆表示该虚拟工具，红色点表示 TCP，绿色点表示把手目标。
  当前抓取点根据网格中两个把手选取，不代表已标定的实体夹爪。
- `config/aviator.yaml` 配置接近时长、规划步长、关节速度、跟踪阈值及冗余逆解种子。
  种子选择肘部朝外的分支，实际动作仍重新求逆解并检查整条轨迹。
- 模型中的 `left_grasp` / `right_grasp` 初始未激活，分别连接 TCP 和操纵盘上的把手 site。
  锁定要求两侧位置误差小于 3 mm、角度误差小于 0.035 rad、相对线/角速度分别小于
  0.02 m/s 和 0.02 rad/s，并持续稳定 0.1 s。两侧一起锁定，远距离请求会被拒绝。
- 接近分为关节空间运动到预接近位姿，以及末端沿笛卡尔路径对准把手。
  锁定后对操纵盘的两个坐标做平滑插值，计算两个把手的目标位姿，再连续求双臂逆解。
  两臂使用同一条时间轴；完整轨迹通过检查后才开始运动。
- 座舱和操纵盘的碰撞网格按 CAD 的分离部件拆开，分别使用凸包近似，保留原外观。
  这避免整块凸包填满座舱空隙。它仍不是精细凹面碰撞或真实夹爪抓握仿真；
  抓取由 weld 模拟，虚拟工具没有碰撞体。轨迹检查采样间隔默认 20 ms，并检查中点。

修改原始 URDF 或抓取配置后，在仓库根目录重新生成并构建两个工程：

```bash
python3 reference/rocos-mujoco/scripts/generate_aviator.py
cmake --build reference/rocos-mujoco/build/aviator-visual -j4
cmake --build AviatorRobot/build -j4
```

生成器同时更新 MJCF、仿真 YAML、碰撞网格和控制 URDF。控制器启动时检查抓取配置与
MJCF 是否一致。构建会复制运行资源到 `build/bin/`，无需修改原始 URDF。

## 通信与底层适配

驱动数据使用仿真器的 `/ecmN`、`/pd_inputN`、`/pd_outputN`。
新工程通过 `ROCOS_MUJOCO_BACKEND` 选择其原始 POSIX 布局，避免误用旧 ECM 的
Boost managed-shared-memory 布局。RCMRobot 原有构建继续使用原后端。

`/aviatorN` 是带版本号的抓取命令和状态通道。进程共享互斥锁保护双臂 14 轴的整批目标
写入与仿真读取；控制器仅使用一个同步周期，两个 Robot 不创建各自的后台运动线程。
该模式明确使用 URDF 运动链，避免工作目录里的 `robotDH.yaml` 替换双臂几何。
驱动解析也支持链中的固定安装段和末端段。

通道包含控制器占用和心跳。控制器检测到反馈超时、跟踪误差或失去锁定时停止两臂；
仿真器检测到锁定误差持续超限或控制器心跳消失时置故障并保持双臂位置。
该工程目前面向 MuJoCo 仿真联调。

## 自动化验证

先构建无头仿真器，再运行测试：

```bash
cmake -S reference/rocos-mujoco -B reference/rocos-mujoco/build/aviator-headless \
  -DCMAKE_BUILD_TYPE=Release -DROCOS_MUJOCO_ENABLE_VISUALIZATION=OFF
cmake --build reference/rocos-mujoco/build/aviator-headless -j4
ctest --test-dir reference/rocos-mujoco/build/aviator-headless --output-on-failure
ctest --test-dir AviatorRobot/build --output-on-failure
```

集成测试自动启动两个独立进程，使用独立总线 ID，完成后清理测试共享内存。
验证未锁定时禁止操纵、仿真端拒绝远距离锁定、接近运动可中止、双侧锁定、非法参数
不改写关节目标、正反向转动/推拉的实测跟踪以及解锁。验收阈值：操纵盘误差小于
0.005 rad / 1 mm，抓取点误差小于 2 mm / 0.01 rad。
如仿真器在别处构建，可通过 CMake 的 `AVIATOR_TEST_SIMULATOR` 指定其可执行文件。
