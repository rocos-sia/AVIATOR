#include <array>
#include <aviator/Aviator.hpp>
#include <chrono>
#include <cmath>
#include <future>
#include <iostream>
#include <limits>
#include <rocos_mujoco/shared_memory_config.hpp>
#include <thread>

using namespace std::chrono_literals;
namespace ipc = rocos_mujoco::aviator;
void require(bool ok, const char *message) {
    if (!ok)
        throw std::runtime_error(message);
}
template <class Operation> void rejected(Operation operation) {
    bool failed = false;
    try {
        operation();
    } catch (const std::runtime_error &error) {
        failed = true;
        std::cout << "Expected rejection: " << error.what() << std::endl;
    }
    require(failed, "Expected command rejection");
}
int main(int argc, char **argv) {
    if (argc != 3)
        return 2;
    const int bus = std::stoi(argv[2]);
    try {
        aviator::Aviator robot(argv[1], bus);
        robot.Init();
        rejected([&] { robot.MoveWheel(.1, -.02); });
        robot.Enable();
        rejected([&] { robot.LockHandles(); });
        // Also exercise simulator-side gating, independently of the controller.
        ipc::Channel channel(bus);
        uint64_t request;
        {
            ipc::Channel::Guard guard(channel);
            request = ++channel.data().request;
            channel.data().command = ipc::Command::Lock;
        }
        for (int i = 0; i < 100 && channel.read().ack != request; ++i)
            std::this_thread::sleep_for(10ms);
        auto f = channel.read();
        require(f.ack == request && f.result == ipc::Result::NotAligned && f.locked == 0,
                "Simulator must refuse distant locking");
        auto cancelled = std::async(std::launch::async, [&] {
            try {
                robot.ApproachHandles();
                return false;
            } catch (const std::runtime_error &) {
                return true;
            }
        });
        for (int i = 0; i < 100 && robot.GetState() != "approaching"; ++i)
            std::this_thread::sleep_for(10ms);
        std::this_thread::sleep_for(500ms);
        robot.Stop();
        require(cancelled.wait_for(2s) == std::future_status::ready && cancelled.get(),
                "Stop failed to interrupt approach");
        require(robot.GetStatus().locked == 0, "Cancelled approach unexpectedly locked");
        robot.ApproachHandles();
        robot.LockHandles();
        require(robot.GetStatus().locked == 3, "Both handles must be locked");
        auto *hw = rocos::SharedMemoryConfig::getInstance(bus);
        auto targets = [&] {
            std::array<int32_t, 14> result{};
            for (int axis = 0; axis < 14; ++axis)
                result[axis] = hw->getSlaveOutputVarValueByName<int32_t>(axis, "Target Position");
            return result;
        };
        const auto before = targets();
        rejected([&] { robot.MoveWheel(.9, -.02); });
        rejected([&] { robot.MoveWheel(0, .01); });
        rejected([&] { robot.MoveWheel(0, -.17); });
        rejected([&] { robot.MoveWheel(std::numeric_limits<double>::quiet_NaN(), -.02); });
        rejected([&] { robot.MoveWheel(0, -.02, 0); });
        require(targets() == before, "Invalid commands changed arm targets");
        for (const auto target : {std::pair<double, double>{.12, -.04}, {-.12, -.07}, {0, -.02}}) {
            robot.MoveWheel(target.first, target.second, 4);
            f = robot.GetStatus();
            std::cout << "Verified wheel: target=" << target.first << ',' << target.second
                      << " actual=" << f.angle << ',' << f.displacement << std::endl;
            require(f.locked == 3 && !f.fault, "Lost grasp while moving");
            require(std::abs(f.angle - target.first) < .005 &&
                        std::abs(f.displacement - target.second) < .001,
                    "Wheel target tracking error");
            for (int side = 0; side < 2; ++side)
                require(f.position_error[side] < .002 && f.rotation_error[side] < .01, "Grasp drift");
        }
        robot.UnlockHandles();
        require(robot.GetStatus().locked == 0, "Unlock failed");
        robot.Disable();
        std::cout << "INTEGRATION PASS\n";
    } catch (const std::exception &error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
    return 0;
}
